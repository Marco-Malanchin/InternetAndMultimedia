% Read the Lena image and diplay it
f = imread('lena.jpg');%leggo l'immagine
imshow(f, []); %mostro l'immagine
title('immagine originale');
figure;

%%%%%%%%%%%%%% AVERAGE FILTER %%%%%%%%%%%%%%
% Create an average filter using the function fspecial (check the slides for details)
h = fspecial("average", [3,3]); %creo l'avarage filter di dimensione 3x3
% Filter the Lena image with the average filter you created using the
%function imfilter 
b = imfilter(f, h);%filtro l'immagine
imshow(b, []);%mostro l'immagine filtrata
title('avarage filter');
figure;

% How does imfilter handle smoothing in edges?
%quando ci sono valori mancanti nella matrice imfilter mette 0 come valore
%mancante, per effettuare questo controllo basta calcolare nel pixel al
%bordo immagine il valore della convoluzione.

%%%%%%%%%%%%%% NON-UNIFORM AVERAGE FILTER %%%%%%%%%%%%%%
% Filters generated with fspecial are uniform. Create a non-uniform average
%filter (i.e., not all elements of the filter have the same weigth)
nh = [0.075 0.125 0.075; 0.125 0.2 0.125; 0.075 0.125 0.075 ]; %creo un filtro con pesi non uniformi
% la somma degli elementi dentro il fltro deve essere 1 perche' non
% vogliamo cambiare la luminosita' dell immagine ma solo ammorbidirla
% se la somma > 1 immagine piu' chiara, < 1 piu' scura
% Filter the Lena image with the non-uniform filter you created
c = imfilter(f,nh); %filtro l'immagine
% Display using subplot the two filtered versions of Lena that you created
%with the average and non-uniform average filter
subplot(1,2,1);      % 1 riga, 2 colonne, prima posizione
imshow(b, []);
title('Average filter');
subplot(1,2,2);      % 1 riga, 2 colonne, seconda posizione
imshow(c, []);
title('Non uniform filter');
figure;
% Do you notice any difference? Try modifying the filter size and weights
%L'immagine filtrata con l'avarage filter è meno sfocata rispetto a quella
%filtrata con il filtro a pesi non omogenei, ed inoltre è più uniforme
%l'effetto di sfocatura

%%%%%%%%%%%%%% GAUSSIAN FILTER %%%%%%%%%%%%%%
% Create a Gaussian filter of size 3𝑥3 and variance 1.5 and visualize it using the function bar3
variance = sqrt(1.5);%metto la radice perchè il filtro gaussiano utilizza la deviazione standard e non la varianza
g = fspecial("gaussian", 3, variance); %creo il filtro gaussiano
bar3(g); %mostro il filtro gaussiano
title('Gaussian filter form');
figure;
% Filter the Lena image with the Gaussian filter 
d = imfilter(f,g);%filtro l'immagine
% Display using subplot the two filtered versions of Lena that you created
%with the average and gaussian filter
subplot(1,2,1);      % 1 riga, 2 colonne, prima posizione
imshow(b, []);
title('Average filter');
subplot(1,2,2);      % 1 riga, 2 colonne, seconda posizione
imshow(d, []);
title('Gaussian filter');
figure;

% Do you notice any difference? Try modifying the filter sizes and the
%variance of the gaussian

%%%%%%%%%%%%%% DENOISING %%%%%%%%%%%%%%
% Create a noisy image by adding salt-and-pepper noise using the imnoise function 
no = imnoise(f); %aggiungo rumore all'immagine
imshow(no, []); %mostro l'immagine
title('Noisy image ');
figure;
% Remove the noise with a median filter
m1 = medfilt2(no, [7, 7]); %filtro 7x7
m2 = medfilt2(no, [5, 5]); %filtro 5x5
m3 = medfilt2(no, [3, 3]); %filtro 3x3

% Display the result of the filtering for different values of filter size 
subplot(1,3,1);      % 1 riga, 3 colonne, prima posizione
imshow(m1, []);
title('7x7 median filter');
subplot(1,3,2);      % 1 riga, 3 colonne, seconda posizione
imshow(m2, []);
title('5x5 median filter');
subplot(1,3,3);      % 1 riga, 3 colonne, terza posizione
imshow(m3, []);
title('3x3 median filter');
figure;
% Remove the noise with an average filter
av = fspecial("average", [7,7]);%filtro avarage 7x7
e = imfilter(no, av);%filtro immagine

% Display the result of the denoising by using the median and the gaussian filter 
subplot(1,2,1);      % 1 riga, 2 colonne, prima posizione
imshow(e, []);
title('Average filter');
subplot(1,2,2);      % 1 riga, 2 colonne, seconda posizione
imshow(m1, []);
title('median filter');
% Do you notice any difference? Try modifying the filter sizes and the
% noise quantity
%avarage filter funziona meglio